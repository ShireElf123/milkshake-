# Whirl Shakes (draft)

Single-file, three-page ecommerce landing site (Home, Shop, Product) with a cart drawer.
"Whirl" is a placeholder brand name. All prices, flavour names and copy are placeholders.

## Run
Open `index.html` in a browser. No build step. GSAP and Matter.js load from cdnjs.

## Notes
- Hero slider: sliding headline, floating fruit, mouse parallax, autoplay.
- Home: sticky stacked cards (desktop) and a grab-and-throw physics fruit section.
- Shop and Product pages with filters, pack sizes, subscribe-and-save, and a cart with discount code PK10.
- Shake and fruit images are rough cut-outs from reference screenshots and should be replaced with generated assets.
